npm i react-native-webview react-native-splash-screen react-native-autoheight-webview --save
npm i react-native-global-props react-native-device-info react-native-camera react-native-calendars --save

