/**
 * List all images using on project
 * @author truongnv
 * @since 2020
 * @version 1.0.0
 */
export const Images = {
  //ic_default_thumb: require('@assets/images/no-thumb-avatar.png'),
};
