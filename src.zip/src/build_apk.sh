
cd android && ./gradlew assembleRelease && cd ..