/**
 * List screen
 * @author truongnv
 * @since 2020
 * @version 1.0.0
 */
