module.exports = {
  general: {
    error: "An error occurred! Please try again!",
  },
  validataion: {},
  componnents: {},
  //Screen
  home: {},
};
