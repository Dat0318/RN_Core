module.exports = {
  general: {
    error: "Có lỗi xảy ra! Xin vui lòng thử lại!",
  },
  validataion: {},
  componnents: {},
  //Screen
  home: {},
};
