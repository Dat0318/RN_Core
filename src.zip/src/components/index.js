import InputCustom from "./InputCustom";

export { InputCustom };
